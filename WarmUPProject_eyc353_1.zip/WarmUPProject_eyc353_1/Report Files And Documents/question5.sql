
SELECT COUNT(*) FROM arrived_books;
SELECT COUNT(*) FROM Book_Author;
SELECT COUNT(*) FROM Bookstore_Publisher_Order;
SELECT COUNT(*) FROM Orders;
SELECT COUNT(*) FROM Reader_Interest;
SELECT COUNT(*) FROM Special_Order;