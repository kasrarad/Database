

NAME OF GROUP ACCOUNT: eyc353_1
[login] 101 => mysql -h eyc353.encs.concordia.ca -u eyc353_1 -p eyc353_1
Enter password: Barr3lR0

---------------------------------------------------------------------------------

MADE BY:
 
Brenden Bissessar 4044016 
Pierre Watine 40027675 
Kasra Laamerad 40020876 
Evan Lamenta 27240007 
The Kien Nguyen 40055738 


For COMP 353 

Professor: Khaled Jababo 

This folder contains:
1) the report
2) the original files and documents that make up the report
3) Originality Form
